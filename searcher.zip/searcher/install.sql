-- Searcher — สร้างฐานข้อมูล (รันใน phpMyAdmin หรือ mysql)
-- หมายเหตุ: api.php สร้างตารางให้อัตโนมัติอยู่แล้ว ไฟล์นี้ใช้เมื่อต้องการสร้างเองล่วงหน้า

CREATE DATABASE IF NOT EXISTS searcher CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE searcher;

CREATE TABLE IF NOT EXISTS people (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  ds            VARCHAR(40)  NOT NULL,              -- key ของชีต (ตรงกับ config.php)
  sid           VARCHAR(40)  NOT NULL,              -- รหัสนักศึกษา / เลขบัตร (ตัวพิมพ์ใหญ่ ไม่มีขีด)
  name          VARCHAR(255) NOT NULL DEFAULT '',
  program       VARCHAR(255) NOT NULL DEFAULT '',
  major         VARCHAR(255) NOT NULL DEFAULT '',
  advisor       VARCHAR(255) NOT NULL DEFAULT '',
  session       VARCHAR(100) NOT NULL DEFAULT '',   -- รอบ (คนเดียวมีได้หลายรอบ)
  room          VARCHAR(100) NOT NULL DEFAULT '',   -- ห้อง / กลุ่ม
  seat          VARCHAR(40)  NOT NULL DEFAULT '',   -- เช่น B05-7 หรือ D01-D06 (ทั้งแถว)
  registered_at DATETIME NULL,                      -- เวลาลงทะเบียน (NULL = ยังไม่ลงทะเบียน)
  released_at   DATETIME NULL,                      -- เวลาที่ฝ่ายเวทีกด "ปล่อย" (NULL = ยังนั่งอยู่)
  UNIQUE KEY uniq_person (ds, sid, session),
  KEY idx_ds_seat (ds, seat)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- สร้างผู้ใช้ฐานข้อมูลเฉพาะ (แนะนำ) แล้วใส่ชื่อ/รหัสนี้ใน config.php
-- CREATE USER 'searcher_user'@'localhost' IDENTIFIED BY 'ตั้งรหัสที่เดายาก';
-- GRANT SELECT, INSERT, UPDATE, DELETE, CREATE ON searcher.* TO 'searcher_user'@'localhost';
