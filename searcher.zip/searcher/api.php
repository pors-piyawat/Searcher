<?php
// ═════════════════════════════════════════════════════════════
//  Searcher API (PHP + MySQL)
//  หน้าเว็บ index.html เรียกไฟล์นี้ด้วย POST JSON: {action, key, ds, ...}
//  ไม่ต้องแก้ไฟล์นี้ — ตั้งค่าทั้งหมดอยู่ใน config.php
// ═════════════════════════════════════════════════════════════
declare(strict_types=1);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');

$CFG = require __DIR__ . '/config.php';
date_default_timezone_set($CFG['timezone'] ?? 'Asia/Bangkok');

function out(array $a) { echo json_encode($a, JSON_UNESCAPED_UNICODE); exit; }
function fail(string $msg, int $code = 400) { http_response_code($code); out(['error' => $msg]); }
function norm_id($s): string { return strtoupper(preg_replace('/[\s\-]/u', '', (string)$s)); }
function str_in($v, int $max = 255): string { return mb_substr(trim((string)($v ?? '')), 0, $max); }
function now(): string { return date('Y-m-d H:i:s'); }

// ── อ่านคำขอ ────────────────────────────────────────────────
$raw = file_get_contents('php://input');
$IN = $raw !== '' ? json_decode($raw, true) : null;
if (!is_array($IN)) $IN = $_POST ?: $_GET;
$action = (string)($IN['action'] ?? '');
$key    = (string)($IN['key'] ?? '');

// ── ชีตจาก config ───────────────────────────────────────────
$SHEETS = [];
foreach ($CFG['sheets'] as $s) {
  if (!preg_match('/^[a-z0-9_]{1,40}$/', $s['key'] ?? '')) continue;
  $SHEETS[$s['key']] = $s;
}

// ── ตรวจรหัสผ่าน → บทบาท ───────────────────────────────────
//   staff = รหัส register (ทุกชีต, ค้นหา + ลงทะเบียน)
//   map   = แอดมิน (ดูผัง + จัดการข้อมูลทุกชีต)
//   stage = ฝ่ายเวที (ดูผัง + ปล่อยที่นั่ง เมื่อคนลุกจากที่นั่ง)
function pw_match(string $given, string $stored): bool {
  if ($stored === '' || $given === '') return false;
  if (strncmp($stored, '$2y$', 4) === 0 || strncmp($stored, '$argon', 6) === 0) return password_verify($given, $stored);
  return hash_equals($stored, $given);
}
$ROLE = null; $ADMIN_DS = null;   // แอดมินใช้รหัสเดียว เข้าได้ทุกชีต
if (pw_match($key, (string)($CFG['admin_password'] ?? ''))) $ROLE = 'map';
if (!$ROLE && pw_match($key, (string)($CFG['stage_password'] ?? ''))) $ROLE = 'stage';
if (!$ROLE && pw_match($key, (string)($CFG['register_password'] ?? ''))) $ROLE = 'staff';
if (!$ROLE) { usleep(600000); out(['auth' => false, 'error' => 'รหัสผ่านไม่ถูกต้อง']); }

$DS = (string)($IN['ds'] ?? '');
if ($action !== 'login' && $action !== 'datasets' && !isset($SHEETS[$DS])) fail('ไม่พบชีตนี้');
function need_admin(): void { global $ROLE; if ($ROLE !== 'map') fail('เฉพาะแอดมิน', 403); }

// ── ฐานข้อมูล ──────────────────────────────────────────────
try {
  $db = new PDO($CFG['db']['dsn'], $CFG['db']['user'] ?? null, $CFG['db']['pass'] ?? null, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
  ]);
} catch (Throwable $e) { fail('เชื่อมต่อฐานข้อมูลไม่ได้ (ตรวจ config.php)', 500); }
$IS_SQLITE = $db->getAttribute(PDO::ATTR_DRIVER_NAME) === 'sqlite';
$db->exec($IS_SQLITE
  ? "CREATE TABLE IF NOT EXISTS people (
       id INTEGER PRIMARY KEY AUTOINCREMENT, ds TEXT NOT NULL, sid TEXT NOT NULL,
       name TEXT NOT NULL DEFAULT '', program TEXT NOT NULL DEFAULT '', major TEXT NOT NULL DEFAULT '',
       advisor TEXT NOT NULL DEFAULT '', session TEXT NOT NULL DEFAULT '', room TEXT NOT NULL DEFAULT '',
       seat TEXT NOT NULL DEFAULT '', registered_at TEXT NULL, released_at TEXT NULL, UNIQUE (ds, sid, session))"
  : "CREATE TABLE IF NOT EXISTS people (
       id INT AUTO_INCREMENT PRIMARY KEY, ds VARCHAR(40) NOT NULL, sid VARCHAR(40) NOT NULL,
       name VARCHAR(255) NOT NULL DEFAULT '', program VARCHAR(255) NOT NULL DEFAULT '', major VARCHAR(255) NOT NULL DEFAULT '',
       advisor VARCHAR(255) NOT NULL DEFAULT '', session VARCHAR(100) NOT NULL DEFAULT '', room VARCHAR(100) NOT NULL DEFAULT '',
       seat VARCHAR(40) NOT NULL DEFAULT '', registered_at DATETIME NULL, released_at DATETIME NULL,
       UNIQUE KEY uniq_person (ds, sid, session), KEY idx_ds_seat (ds, seat)
     ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

// อัปเกรดตารางเดิม: เพิ่มคอลัมน์ released_at (ปล่อยที่นั่ง) ถ้ายังไม่มี
try { $db->query('SELECT released_at FROM people LIMIT 1'); }
catch (Throwable $e) { $db->exec('ALTER TABLE people ADD COLUMN released_at ' . ($IS_SQLITE ? 'TEXT' : 'DATETIME') . ' NULL'); }

function q(string $sql, array $p = []): PDOStatement { global $db; $st = $db->prepare($sql); $st->execute($p); return $st; }
function entry(array $r, bool $withRow = false): array {
  $e = ['id' => $r['sid'], 'name' => $r['name'], 'program' => $r['program'], 'major' => $r['major'],
        'advisor' => $r['advisor'], 'session' => $r['session'], 'room' => $r['room'],
        'seat' => strtoupper($r['seat']), 'registeredAt' => $r['registered_at'] ? substr((string)$r['registered_at'], 0, 19) : ''];
  if ($withRow) $e['rowid'] = (int)$r['id'];
  return $e;
}
function stats_of(string $ds, bool $detail = false): array {
  $rows = q('SELECT session, room, major, program, registered_at FROM people WHERE ds=?', [$ds])->fetchAll();
  $total = count($rows); $reg = 0;
  $g = ['bySession' => [], 'byRoom' => [], 'byMajor' => [], 'byProgram' => []];
  $f = ['bySession' => 'session', 'byRoom' => 'room', 'byMajor' => 'major', 'byProgram' => 'program'];
  foreach ($rows as $r) {
    $ok = !empty($r['registered_at']); if ($ok) $reg++;
    if (!$detail) continue;
    foreach ($f as $k => $col) {
      $n = $r[$col] !== '' ? $r[$col] : '(ไม่ระบุ)';
      $g[$k][$n] ??= ['name' => $n, 'total' => 0, 'registered' => 0];
      $g[$k][$n]['total']++; if ($ok) $g[$k][$n]['registered']++;
    }
  }
  $res = ['total' => $total, 'registered' => $reg];
  if ($detail) foreach ($g as $k => $m) {
    $list = array_values($m);
    usort($list, fn($a, $b) => strnatcasecmp($a['name'], $b['name']));
    $res[$k] = $list;
  }
  return $res;
}
function sheet_info(string $k): array {
  global $SHEETS;
  $s = $SHEETS[$k];
  $sessions = (int)q('SELECT COUNT(DISTINCT session) c FROM people WHERE ds=?', [$k])->fetch()['c'];
  $st = stats_of($k);
  $d = ['key' => $k, 'label' => $s['label'] ?? $k, 'idLabel' => $s['id_label'] ?? 'รหัสนักศึกษา',
        'idType' => $s['id_type'] ?? '', 'ready' => true, 'tabs' => max(1, $sessions),
        'total' => $st['total'], 'registered' => $st['registered']];
  if (!empty($s['labels']) && is_array($s['labels'])) $d['labels'] = $s['labels'];
  return $d;
}
function find_person(string $ds, string $sid): array {
  $rows = q('SELECT * FROM people WHERE ds=? AND sid=? ORDER BY session, id', [$ds, $sid])->fetchAll();
  return array_map('entry', $rows);
}
function parse_seat(string $code): ?array {
  $code = strtoupper(trim($code));
  if (preg_match('/^([A-Z])(\d+)-([A-Z])(\d+)$/', $code, $m) && $m[1] === $m[3])
    return ['zone' => $m[1], 'row' => min((int)$m[2], (int)$m[4]), 'rowEnd' => max((int)$m[2], (int)$m[4]), 'seat' => null];
  if (preg_match('/^([A-Z])(\d+)(?:-(\d+))?$/', $code, $m))
    return ['zone' => $m[1], 'row' => (int)$m[2], 'rowEnd' => (int)$m[2], 'seat' => isset($m[3]) && $m[3] !== '' ? (int)$m[3] : null];
  return null;
}
function clean_row(array $r): ?array {
  $sid = norm_id($r['id'] ?? '');
  if ($sid === '' || mb_strlen($sid) > 40) return null;
  return ['sid' => $sid, 'name' => str_in($r['name'] ?? ''), 'program' => str_in($r['program'] ?? ''),
          'major' => str_in($r['major'] ?? ''), 'advisor' => str_in($r['advisor'] ?? ''),
          'session' => str_in($r['session'] ?? '', 100), 'room' => str_in($r['room'] ?? '', 100),
          'seat' => strtoupper(str_in($r['seat'] ?? '', 40))];
}
function upsert(string $ds, array $c): string {
  $ex = q('SELECT id FROM people WHERE ds=? AND sid=? AND session=?', [$ds, $c['sid'], $c['session']])->fetch();
  if ($ex) {
    q('UPDATE people SET name=?, program=?, major=?, advisor=?, room=?, seat=? WHERE id=?',
      [$c['name'], $c['program'], $c['major'], $c['advisor'], $c['room'], $c['seat'], $ex['id']]);
    return 'updated';
  }
  q('INSERT INTO people (ds, sid, name, program, major, advisor, session, room, seat) VALUES (?,?,?,?,?,?,?,?,?)',
    [$ds, $c['sid'], $c['name'], $c['program'], $c['major'], $c['advisor'], $c['session'], $c['room'], $c['seat']]);
  return 'inserted';
}

// ── คำสั่ง ─────────────────────────────────────────────────
switch ($action) {

  case 'login':
    out(['ok' => true, 'role' => $ROLE, 'ds' => $ADMIN_DS]);

  case 'datasets':
    $keys = $ADMIN_DS ? [$ADMIN_DS] : array_keys($SHEETS);
    out(['datasets' => array_map('sheet_info', $keys), 'role' => $ROLE, 'adminDs' => $ADMIN_DS]);

  case 'lookup':
    $sid = norm_id($IN['id'] ?? '');
    $list = $sid === '' ? [] : find_person($DS, $sid);
    $res = ['found' => count($list) > 0, 'matches' => $list, 'stats' => stats_of($DS)];
    if ($list) $res += $list[0];
    out($res);

  case 'register':
    $sid = norm_id($IN['id'] ?? ''); $sess = str_in($IN['session'] ?? '', 100);
    q('UPDATE people SET registered_at=? WHERE ds=? AND sid=? AND session=? AND registered_at IS NULL', [now(), $DS, $sid, $sess]);
    $list = find_person($DS, $sid);
    out(['found' => count($list) > 0, 'matches' => $list, 'stats' => stats_of($DS)]);

  case 'stats':
    out(stats_of($DS, !empty($IN['detail'])));

  case 'seats':
    $seats = []; $rooms = []; $rel = []; $people = 0; $noSeat = 0;
    foreach (q('SELECT seat, room, released_at FROM people WHERE ds=?', [$DS]) as $r) {
      $people++; $s = strtoupper($r['seat']);
      if ($s === '') { $noSeat++; continue; }
      // การปล่อยที่นั่งเห็นเฉพาะโหมดเวที — แอดมิน/เจ้าหน้าที่ยังเห็นที่นั่งตามปกติ
      if ($ROLE === 'stage' && !empty($r['released_at'])) { $rel[$s] = ($rel[$s] ?? 0) + 1; continue; }
      $seats[$s] = ($seats[$s] ?? 0) + 1;
      if (!array_key_exists($s, $rooms)) $rooms[$s] = $r['room'];
    }
    out(['seats' => (object)$seats, 'rooms' => (object)$rooms, 'released' => (object)$rel, 'people' => $people, 'noSeat' => $noSeat]);

  case 'release':
    // ฝ่ายเวที: ปล่อยที่นั่ง (คนลุกจากที่นั่ง) / undo=1 คืนที่นั่ง
    // codes = รหัสที่นั่งตามที่บันทึกไว้ เช่น B05-7 หรือ D01-D06 (หน้าเว็บคำนวณว่าช่วงไหนถูกเลือกครบ)
    if ($ROLE !== 'stage') fail('เฉพาะฝ่ายเวที', 403);
    $codes = array_values(array_unique(array_filter(array_map(fn($c) => strtoupper(str_in($c, 40)), (array)($IN['codes'] ?? [])))));
    if (count($codes) > 5000) fail('เลือกมากเกินไป');
    $undo = !empty($IN['undo']); $n = 0;
    $db->beginTransaction();
    foreach (array_chunk($codes, 200) as $chunk) {
      $ph = implode(',', array_fill(0, count($chunk), '?'));
      $n += $undo
        ? q("UPDATE people SET released_at=NULL WHERE ds=? AND released_at IS NOT NULL AND UPPER(seat) IN ($ph)", array_merge([$DS], $chunk))->rowCount()
        : q("UPDATE people SET released_at=? WHERE ds=? AND released_at IS NULL AND UPPER(seat) IN ($ph)", array_merge([now(), $DS], $chunk))->rowCount();
    }
    $db->commit();
    out(['ok' => true, 'count' => $n, 'undo' => $undo]);

  case 'release_reset':
    if ($ROLE !== 'stage') fail('เฉพาะฝ่ายเวที', 403);
    $n = q('UPDATE people SET released_at=NULL WHERE ds=? AND released_at IS NOT NULL', [$DS])->rowCount();
    out(['ok' => true, 'count' => $n]);

  case 'seatinfo':
    $t = parse_seat((string)($IN['seat'] ?? ''));
    if (!$t || $t['seat'] === null) out(['count' => 0, 'people' => []]);
    $list = [];
    foreach (q('SELECT * FROM people WHERE ds=? AND seat LIKE ?', [$DS, $t['zone'] . '%']) as $r) {
      $p = parse_seat($r['seat']);
      if (!$p || $p['zone'] !== $t['zone'] || $t['row'] < $p['row'] || $t['row'] > $p['rowEnd']) continue;
      if ($p['seat'] !== null && $p['seat'] !== $t['seat']) continue;
      $list[] = entry($r) + ['exact' => $p['seat'] !== null];
    }
    usort($list, fn($a, $b) => ($b['exact'] <=> $a['exact']));
    out(['count' => count($list), 'people' => $list]);

  // ── จัดการข้อมูล (เฉพาะแอดมินของชีต) ──────────────────────
  case 'rows':
    need_admin();
    $rows = q('SELECT * FROM people WHERE ds=? ORDER BY sid, session', [$DS])->fetchAll();
    out(['rows' => array_map(fn($r) => entry($r, true), $rows), 'sheet' => sheet_info($DS)]);

  case 'save_row':
    need_admin();
    $c = clean_row((array)($IN['row'] ?? []));
    if (!$c) fail('กรุณากรอกรหัส');
    $rowid = (int)($IN['row']['rowid'] ?? 0);
    $dup = q('SELECT id FROM people WHERE ds=? AND sid=? AND session=?', [$DS, $c['sid'], $c['session']])->fetch();
    if ($dup && (int)$dup['id'] !== $rowid) fail('มีรหัส ' . $c['sid'] . ($c['session'] !== '' ? ' รอบ ' . $c['session'] : '') . ' อยู่แล้ว');
    if ($rowid) {
      q('UPDATE people SET sid=?, name=?, program=?, major=?, advisor=?, session=?, room=?, seat=? WHERE id=? AND ds=?',
        [$c['sid'], $c['name'], $c['program'], $c['major'], $c['advisor'], $c['session'], $c['room'], $c['seat'], $rowid, $DS]);
    } else upsert($DS, $c);
    out(['ok' => true]);

  case 'delete_row':
    need_admin();
    $ids = array_map('intval', (array)($IN['rowids'] ?? [$IN['rowid'] ?? 0]));
    $n = 0; foreach ($ids as $id) $n += q('DELETE FROM people WHERE id=? AND ds=?', [$id, $DS])->rowCount();
    out(['ok' => true, 'deleted' => $n]);

  case 'set_reg':
    need_admin();
    q('UPDATE people SET registered_at=? WHERE id=? AND ds=?', [!empty($IN['registered']) ? now() : null, (int)($IN['rowid'] ?? 0), $DS]);
    out(['ok' => true]);

  case 'clear_regs':
    need_admin();
    $n = q('UPDATE people SET registered_at=NULL WHERE ds=? AND registered_at IS NOT NULL', [$DS])->rowCount();
    out(['ok' => true, 'cleared' => $n]);

  case 'save_rows':
    // บันทึกจากตารางแบบ Excel: {changes:[{rowid, id, name, ...}], deletes:[rowid]}
    need_admin();
    $changes = (array)($IN['changes'] ?? []); $deletes = array_map('intval', (array)($IN['deletes'] ?? []));
    if (count($changes) > 20000) fail('แก้ไขพร้อมกันได้ไม่เกิน 20,000 แถว');
    // จำลองผลลัพธ์ก่อน เพื่อตรวจรหัส+รอบซ้ำ แล้วค่อยเขียนจริง
    $final = [];
    foreach (q('SELECT id, sid, session FROM people WHERE ds=?', [$DS]) as $r) $final[(int)$r['id']] = $r['sid'] . "\x1f" . $r['session'];
    foreach ($deletes as $id) unset($final[$id]);
    $errors = []; $clean = [];
    foreach ($changes as $i => $ch) {
      $ch = (array)$ch; $rid = (int)($ch['rowid'] ?? 0);
      $c = clean_row($ch);
      if (!$c) { $errors[] = ['i' => $i, 'error' => 'ไม่มีรหัส']; continue; }
      if ($rid && !array_key_exists($rid, $final)) { $errors[] = ['i' => $i, 'error' => 'แถวนี้ถูกลบไปแล้ว']; continue; }
      $clean[$i] = [$rid, $c];
      $final[$rid ?: 'n' . $i] = $c['sid'] . "\x1f" . $c['session'];
    }
    $seen = [];
    foreach ($final as $k => $v) $seen[$v][] = $k;
    foreach ($clean as $i => [$rid, $c]) {
      if (count($seen[$c['sid'] . "\x1f" . $c['session']]) > 1)
        $errors[] = ['i' => $i, 'error' => 'รหัส ' . $c['sid'] . ($c['session'] !== '' ? ' รอบ ' . $c['session'] : '') . ' ซ้ำ'];
    }
    if ($errors) out(['ok' => false, 'errors' => $errors, 'error' => 'มีแถวที่ต้องแก้ ' . count($errors) . ' แถว']);
    $db->beginTransaction();
    try {
      foreach ($deletes as $id) q('DELETE FROM people WHERE id=? AND ds=?', [$id, $DS]);
      // ย้ายรหัสชั่วคราวก่อน กันชนกันเมื่อสลับรหัส/รอบระหว่างแถว
      foreach ($clean as [$rid, $c]) if ($rid) q('UPDATE people SET sid=? WHERE id=? AND ds=?', ['~' . $rid, $rid, $DS]);
      $ins = 0; $upd = 0;
      foreach ($clean as [$rid, $c]) {
        if ($rid) {
          q('UPDATE people SET sid=?, name=?, program=?, major=?, advisor=?, session=?, room=?, seat=? WHERE id=? AND ds=?',
            [$c['sid'], $c['name'], $c['program'], $c['major'], $c['advisor'], $c['session'], $c['room'], $c['seat'], $rid, $DS]);
          $upd++;
        } else {
          q('INSERT INTO people (ds, sid, name, program, major, advisor, session, room, seat) VALUES (?,?,?,?,?,?,?,?,?)',
            [$DS, $c['sid'], $c['name'], $c['program'], $c['major'], $c['advisor'], $c['session'], $c['room'], $c['seat']]);
          $ins++;
        }
      }
      $db->commit();
    } catch (Throwable $e) { $db->rollBack(); fail('บันทึกไม่สำเร็จ: ' . $e->getMessage(), 500); }
    out(['ok' => true, 'inserted' => $ins, 'updated' => $upd, 'deleted' => count($deletes)]);

  case 'import':
    need_admin();
    $rows = (array)($IN['rows'] ?? []);
    if (count($rows) > 20000) fail('ไฟล์ใหญ่เกินไป (เกิน 20,000 แถว)');
    $mode = ($IN['mode'] ?? 'append') === 'replace' ? 'replace' : 'append';
    $ins = 0; $upd = 0; $skip = 0;
    $db->beginTransaction();
    try {
      if ($mode === 'replace') q('DELETE FROM people WHERE ds=?', [$DS]);
      foreach ($rows as $r) {
        $c = is_array($r) ? clean_row($r) : null;
        if (!$c) { $skip++; continue; }
        upsert($DS, $c) === 'inserted' ? $ins++ : $upd++;
      }
      $db->commit();
    } catch (Throwable $e) { $db->rollBack(); fail('นำเข้าไม่สำเร็จ: ' . $e->getMessage(), 500); }
    out(['ok' => true, 'inserted' => $ins, 'updated' => $upd, 'skipped' => $skip, 'mode' => $mode]);

  default:
    fail('ไม่รู้จักคำสั่ง');
}
